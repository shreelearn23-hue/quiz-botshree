# ShreeLearn — GitHub Pages starter

This repository contains the HTML homepage supplied in `Ha.docx`.

## Preview locally
Open `index.html` in a modern browser. An internet connection is needed for Tailwind CSS and Font Awesome because they are loaded from CDNs.

## Publish with GitHub Pages
1. Create a new GitHub repository (for example, `shreelearn`).
2. Upload `index.html`, `README.md`, and `.nojekyll` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then save.
6. Wait for GitHub Pages to publish the site.

## Important limitations in the supplied code
- This is a static HTML landing page; it does not include a backend, login, database, or a working exam engine.
- Links such as `/exam` point to a route that is not implemented in this project yet.
- The PDF/audio/video modal content is currently placeholder/demo content; real notes and media need to be connected.
- The page loads Tailwind CSS and Font Awesome from external CDNs.

To make the CBT exam and resource links functional, add the exam page and any required backend/API separately.
